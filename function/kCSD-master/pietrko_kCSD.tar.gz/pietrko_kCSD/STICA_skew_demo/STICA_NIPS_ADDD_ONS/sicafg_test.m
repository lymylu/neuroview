ndata = 100; k = 2;
X = rand(ndata, k);

A = [1 1; 1 -1];
X = X*A;

data.X = [X ones(size(X, 1), 1)];
data.a = 4*ones(1, k);
data.b = 1*ones(1, k);

W0 = 0.01*randn(k+1, k); w0 = W0(:);
gradtest('sicafg', w0, data, sqrt(eps));
